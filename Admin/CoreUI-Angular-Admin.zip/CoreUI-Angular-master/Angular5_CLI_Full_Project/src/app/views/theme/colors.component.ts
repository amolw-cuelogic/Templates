import { Component } from '@angular/core';

@Component({
  templateUrl: 'colors.component.html'
})
export class ColorsComponent {

  constructor() { }

}
